from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func # 데이터베이스 함수 (예: 현재 시간) 사용을 위해 임포트
from pgvector.sqlalchemy import Vector # pgvector의 벡터 타입을 사용하기 위해 임포트
from .database import Base # 앞에서 정의한 Base 클래스 임포트

# User (사용자) 엔터티 모델
class User(Base):
    __tablename__ = "users" # 데이터베이스 테이블 이름 정의

    # 컬럼 정의
    id = Column(String, primary_key=True, index=True) # 사용자 고유 ID (UUID 형태로 저장하기 위해 String 사용), 기본 키, 인덱스 생성
    name = Column(String, nullable=False) # 사용자 이름, Null 허용 안함
    preference = Column(String, nullable=True) # 사용자 선호 카테고리 (예: "한식, 카페"), Null 허용
    created_at = Column(DateTime, server_default=func.now()) # 생성 시간, 기본값으로 현재 시각 자동 설정
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now()) # 업데이트 시간, 생성 시 현재 시각, 업데이트 시 자동 갱신

    # 관계 정의 (다른 테이블과의 관계)
    reviews = relationship("Review", back_populates="user") # User와 Review 간의 1:N 관계
    recommendations = relationship("Recommendation", back_populates="user") # User와 Recommendation 간의 1:N 관계

# Restaurant (맛집) 엔터티 모델
class Restaurant(Base):
    __tablename__ = "restaurants" # 데이터베이스 테이블 이름 정의

    # 컬럼 정의
    id = Column(String, primary_key=True, index=True) # 맛집 고유 ID (UUID 형태로 저장하기 위해 String 사용), 기본 키, 인덱스 생성
    name = Column(String, nullable=False) # 맛집 이름, Null 허용 안함
    category = Column(String, nullable=False) # 맛집 카테고리 (예: "한식", "양식"), Null 허용 안함
    location = Column(String, nullable=False) # 맛집 위치, Null 허용 안함
    description = Column(Text, nullable=True) # 맛집 상세 설명, Null 허용
    
    # LLM 텍스트 임베딩 컬럼
    # 맛집 설명(description)을 벡터화하여 저장합니다.
    # OpenAI 'text-embedding-3-small' 모델은 1536차원 벡터를 반환합니다.
    text_embedding = Column(Vector(1536), nullable=True)

    # 이미지 임베딩 컬럼
    # 맛집 이미지 데이터를 벡터화하여 저장합니다.
    # CLIP과 같은 이미지 임베딩 모델의 차원(예: 512차원)에 맞춰 설정합니다.
    image_embedding = Column(Vector(512), nullable=True)

    created_at = Column(DateTime, server_default=func.now()) # 생성 시간
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now()) # 업데이트 시간

    # 관계 정의
    reviews = relationship("Review", back_populates="restaurant") # Restaurant와 Review 간의 1:N 관계

# Review (리뷰) 엔터티 모델
class Review(Base):
    __tablename__ = "reviews" # 데이터베이스 테이블 이름 정의

    # 컬럼 정의
    id = Column(String, primary_key=True, index=True) # 리뷰 고유 ID (UUID 형태로 저장), 기본 키, 인덱스 생성
    user_id = Column(String, ForeignKey("users.id")) # 리뷰 작성 사용자 ID (users 테이블의 id 참조), 외래 키
    restaurant_id = Column(String, ForeignKey("restaurants.id")) # 리뷰 대상 맛집 ID (restaurants 테이블의 id 참조), 외래 키
    content = Column(Text, nullable=False) # 리뷰 내용, Null 허용 안함
    rating = Column(Integer, nullable=False) # 평점 (1~5점), Null 허용 안함
    
    # 리뷰 내용 임베딩 컬럼
    # 리뷰 내용(content)을 벡터화하여 저장합니다.
    # OpenAI 'text-embedding-3-small' 모델은 1536차원 벡터를 반환합니다.
    review_embedding = Column(Vector(1536), nullable=True)

    created_at = Column(DateTime, server_default=func.now()) # 생성 시간
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now()) # 업데이트 시간

    # 관계 정의
    user = relationship("User", back_populates="reviews") # Review와 User 간의 N:1 관계
    restaurant = relationship("Restaurant", back_populates="reviews") # Review와 Restaurant 간의 N:1 관계
    # Review와 ReviewSummary 간의 1:1 관계 (uselist=False로 단일 객체임을 명시)
    summary = relationship("ReviewSummary", back_populates="review", uselist=False) 

# ReviewSummary (리뷰 요약) 엔터티 모델
class ReviewSummary(Base):
    __tablename__ = "review_summaries" # 데이터베이스 테이블 이름 정의

    # 컬럼 정의
    id = Column(String, primary_key=True, index=True) # 요약 고유 ID (UUID 형태로 저장), 기본 키, 인덱스 생성
    review_id = Column(String, ForeignKey("reviews.id"), unique=True) # 요약 대상 리뷰 ID (reviews 테이블의 id 참조), 외래 키, 고유(unique=True) 설정으로 1:1 관계 보장
    keywords = Column(Text, nullable=True) # LLM이 요약한 핵심 키워드 (콤마 등으로 구분된 문자열)
    positive_summary = Column(Text, nullable=True) # LLM이 요약한 긍정적인 내용
    negative_summary = Column(Text, nullable=True) # LLM이 요약한 부정적인 내용
    full_summary = Column(Text, nullable=True) # LLM이 요약한 전체 내용
    sentiment = Column(String, nullable=True) # LLM이 분석한 전반적인 감정 (예: 'positive', 'neutral', 'negative')
    
    created_at = Column(DateTime, server_default=func.now()) # 생성 시간

    # 관계 정의
    review = relationship("Review", back_populates="summary") # ReviewSummary와 Review 간의 N:1 관계

# Recommendation (추천 이력) 엔터티 모델 (선택 사항: 추천 기록을 남기고 싶을 때 사용)
class Recommendation(Base):
    __tablename__ = "recommendations" # 데이터베이스 테이블 이름 정의

    # 컬럼 정의
    id = Column(String, primary_key=True, index=True) # 추천 기록 고유 ID (UUID 형태로 저장), 기본 키, 인덱스 생성
    user_id = Column(String, ForeignKey("users.id")) # 추천을 받은 사용자 ID (users 테이블의 id 참조), 외래 키
    restaurant_id = Column(String, ForeignKey("restaurants.id")) # 추천된 맛집 ID (restaurants 테이블의 id 참조), 외래 키
    recommendation_score = Column(Integer, nullable=True) # 추천 시 계산된 점수 (예: 유사도 점수)
    recommendation_type = Column(String, nullable=True) # 어떤 방식으로 추천되었는지 (예: "category_match", "vector_similarity", "hybrid")
    created_at = Column(DateTime, server_default=func.now()) # 생성 시간

    # 관계 정의
    user = relationship("User", back_populates="recommendations") # Recommendation과 User 간의 N:1 관계