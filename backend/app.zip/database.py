from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

# 데이터베이스 연결 URL 설정
# os.getenv를 사용하여 환경 변수에서 DATABASE_URL을 로드합니다.
# 실제 배포 시에는 보안을 위해 환경 변수 사용을 강력히 권장합니다.
# 환경 변수가 없을 경우 기본값으로 로컬 PostgreSQL 연결 문자열을 사용합니다.
SQLALCHEMY_DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:213427@localhost:5432/fastapi_db")

# SQLAlchemy 엔진 생성
# 이 엔진은 데이터베이스와의 실제 연결을 관리합니다.
engine = create_engine(SQLALCHEMY_DATABASE_URL)

# 데이터베이스 세션 팩토리 생성
# SessionLocal 인스턴스는 각 요청에 대한 데이터베이스 세션 역할을 합니다.
# autocommit=False: 트랜잭션이 자동으로 커밋되지 않도록 하여 수동 제어를 가능하게 합니다.
# autoflush=False: 변경 사항이 자동으로 데이터베이스에 플러시되지 않도록 하여 성능을 최적화합니다.
# bind=engine: 생성된 엔진에 세션을 바인딩합니다.
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# SQLAlchemy ORM 모델의 기본 클래스
# 모든 SQLAlchemy 모델은 이 Base 클래스를 상속받아야 합니다.
Base = declarative_base()

# 의존성 주입을 위한 DB 세션 가져오기 함수
# FastAPI에서 Depends(get_db)와 함께 사용하여 요청마다 새로운 DB 세션을 제공합니다.
def get_db():
    db = SessionLocal() # 새로운 세션 생성
    try:
        yield db # 세션을 FastAPI 라우트 핸들러에 제공
    finally:
        db.close() # 요청 처리가 끝나면 세션 반환 및 종료

def enable_pgvector_extension():
    """
    PostgreSQL 데이터베이스에 'vector' 확장을 활성화합니다.
    pgvector를 사용하여 벡터 데이터를 저장하고 유사도 검색을 수행하기 위해 필요합니다.
    애플리케이션 시작 시 (main.py의 startup 이벤트) 한 번 호출되어야 합니다.
    """
    conn = engine.connect() # 엔진에서 데이터베이스 연결 가져오기
    try:
        # CREATE EXTENSION IF NOT EXISTS: 'vector' 확장이 이미 설치되어 있다면 오류 없이 넘어갑니다.
        conn.execute("CREATE EXTENSION IF NOT EXISTS vector;")
        conn.commit() # DDL(데이터 정의 언어) 문은 트랜잭션 내에서 실행되므로 커밋이 필요합니다.
    except Exception as e:
        print(f"Error enabling pgvector extension: {e}")
        conn.rollback() # 오류 발생 시 롤백
    finally:
        conn.close() # 연결 닫기

# 데이터베이스의 모든 테이블 생성 함수
# Base.metadata에 정의된 모든 모델을 기반으로 데이터베이스에 테이블을 생성합니다.
# 애플리케이션 시작 시 (main.py의 startup 이벤트) 호출됩니다.
def create_all_tables():
    Base.metadata.create_all(bind=engine)