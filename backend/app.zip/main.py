from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.responses import JSONResponse # JSON 응답을 위해 추가
from sqlalchemy.orm import Session
from typing import List
import uuid
import json
import numpy as np
import os # 파일 저장을 위해 os 모듈 추가
import uvicorn  # Uvicorn 임포트
from . import models, schemas, database, llm_service

# FastAPI 앱 초기화
app = FastAPI(
    title="맛집 추천 API",
    description="PostgreSQL, pgvector, FastAPI, LLM 기반의 맛집 추천 및 관리 시스템",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# 애플리케이션 시작 시 DB 테이블 생성 및 pgvector 확장 활성화
@app.on_event("startup")
async def startup_event():
    database.create_all_tables()
    database.enable_pgvector_extension()
    print("Database tables created and pgvector extension enabled.")

# DB 세션 의존성
def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

### ----------------------------------------------------
###                   User Endpoints
### ----------------------------------------------------
# ... (기존 User Endpoints 코드는 동일) ...
@app.post("/users/", response_model=schemas.User, summary="새 사용자 생성")
async def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = models.User(**user.dict())
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@app.get("/users/", response_model=List[schemas.User], summary="모든 사용자 조회")
async def read_users(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    users = db.query(models.User).offset(skip).limit(limit).all()
    return users

@app.get("/users/{user_id}", response_model=schemas.User, summary="특정 사용자 조회")
async def read_user(user_id: str, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user

### ----------------------------------------------------
###                 Restaurant Endpoints
### ----------------------------------------------------
# ... (기존 Restaurant Endpoints 코드는 동일) ...
@app.post("/restaurants/", response_model=schemas.Restaurant, summary="새 맛집 생성 및 설명 임베딩")
async def create_restaurant(restaurant: schemas.RestaurantCreate, db: Session = Depends(get_db)):
    text_emb = None
    if restaurant.description:
        text_emb = llm_service.get_text_embedding(restaurant.description)
    
    db_restaurant = models.Restaurant(
        **restaurant.dict(),
        text_embedding=text_emb.tolist() if text_emb is not None and text_emb.size > 0 else None
    )
    db.add(db_restaurant)
    db.commit()
    db.refresh(db_restaurant)
    return db_restaurant

@app.get("/restaurants/", response_model=List[schemas.Restaurant], summary="모든 맛집 조회")
async def read_restaurants(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    restaurants = db.query(models.Restaurant).offset(skip).limit(limit).all()
    return restaurants

@app.get("/restaurants/{restaurant_id}", response_model=schemas.Restaurant, summary="특정 맛집 조회")
async def read_restaurant(restaurant_id: str, db: Session = Depends(get_db)):
    restaurant = db.query(models.Restaurant).filter(models.Restaurant.id == restaurant_id).first()
    if restaurant is None:
        raise HTTPException(status_code=404, detail="Restaurant not found")
    return restaurant

@app.post("/restaurants/{restaurant_id}/upload_image", summary="맛집 이미지 업로드 및 임베딩 저장")
async def upload_restaurant_image(
    restaurant_id: str, 
    file: UploadFile = File(..., description="업로드할 이미지 파일"),
    db: Session = Depends(get_db)
):
    restaurant = db.query(models.Restaurant).filter(models.Restaurant.id == restaurant_id).first()
    if not restaurant:
        raise HTTPException(status_code=404, detail="Restaurant not found")
    
    image_data = await file.read()
    image_emb = llm_service.get_image_embedding(image_data)
    
    if image_emb.size == 0:
        raise HTTPException(status_code=500, detail="Failed to generate image embedding.")

    restaurant.image_embedding = image_emb.tolist()
    db.commit()
    return {"message": "Image embedding saved successfully."}

### ----------------------------------------------------
###                   Review Endpoints
### ----------------------------------------------------
# ... (기존 Review Endpoints 코드는 동일) ...
def create_review_summary_task(review_id: str, review_content: str, db_session: Session):
    try:
        summary_data = llm_service.summarize_review_with_llm(review_content)
        db_summary = models.ReviewSummary(
            id=str(uuid.uuid4()),
            review_id=review_id,
            keywords=summary_data.get("keywords"),
            positive_summary=summary_data.get("positive_summary"),
            negative_summary=summary_data.get("negative_summary"),
            full_summary=summary_data.get("full_summary"),
            sentiment=summary_data.get("sentiment")
        )
        db_session.add(db_summary)
        db_session.commit()
    except Exception as e:
        print(f"Background task failed to summarize review {review_id} with LLM: {e}")
        db_session.rollback()
    finally:
        db_session.close()

@app.post("/reviews/", response_model=schemas.Review, summary="새 리뷰 작성 및 임베딩, 요약 요청")
async def create_review(
    review: schemas.ReviewCreate, 
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    review_emb = llm_service.get_text_embedding(review.content)
    
    db_review = models.Review(
        **review.dict(),
        review_embedding=review_emb.tolist() if review_emb.size > 0 else None
    )
    db.add(db_review)
    db.commit()
    db.refresh(db_review)

    background_db_session = database.SessionLocal()
    background_tasks.add_task(
        create_review_summary_task, 
        review_id=db_review.id, 
        review_content=db_review.content, 
        db_session=background_db_session
    )

    return db_review

@app.get("/reviews/", response_model=List[schemas.Review], summary="모든 리뷰 조회")
async def read_reviews(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    reviews = db.query(models.Review).offset(skip).limit(limit).all()
    return reviews

@app.get("/reviews/{review_id}/summary", response_model=schemas.ReviewSummary, summary="리뷰 요약 조회")
async def get_review_summary(review_id: str, db: Session = Depends(get_db)):
    summary = db.query(models.ReviewSummary).filter(models.ReviewSummary.review_id == review_id).first()
    if summary is None:
        raise HTTPException(status_code=404, detail="Review summary not found")
    return summary

### ----------------------------------------------------
###                 Recommendation Endpoints
### ----------------------------------------------------
# ... (기존 Recommendation Endpoints 코드는 동일) ...
@app.get("/recommendations/{user_id}", response_model=List[schemas.RecommendedRestaurant], summary="사용자 맞춤 맛집 추천")
async def get_recommendations_for_user(user_id: str, top_n: int = 5, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    
    if not user.preference:
        raise HTTPException(status_code=400, detail="User preference not set for recommendation. Please update user profile.")
    
    recommended_restaurants = []

    preferred_categories = [p.strip() for p in user.preference.split(',') if p.strip()]
    
    candidate_restaurants = db.query(models.Restaurant).filter(
        models.Restaurant.category.in_(preferred_categories)
    ).all()

    if not candidate_restaurants:
        print(f"No restaurants found for preferred categories: {preferred_categories}. Falling back to all restaurants.")
        candidate_restaurants = db.query(models.Restaurant).all()
        
        if not candidate_restaurants:
            return []
        
        user_reviews = db.query(models.Review).filter(
            models.Review.user_id == user_id, 
            models.Review.review_embedding.isnot(None)
        ).all()
        if not user_reviews:
            raise HTTPException(status_code=400, detail="No user reviews available for recommendation after category filtering failed.")

        user_combined_embedding = np.mean([np.array(r.review_embedding) for r in user_reviews], axis=0)

        restaurant_scores = []
        for rest in candidate_restaurants:
            if rest.text_embedding:
                score = llm_service.cosine_similarity(user_combined_embedding, np.array(rest.text_embedding))
                restaurant_scores.append((rest, score))
        
        restaurant_scores.sort(key=lambda x: x[1], reverse=True)
        return [schemas.RecommendedRestaurant(restaurant=r, similarity_score=s) for r, s in restaurant_scores[:top_n]]

    user_reviews = db.query(models.Review).filter(
        models.Review.user_id == user_id, 
        models.Review.review_embedding.isnot(None)
    ).all()
    
    if not user_reviews:
        print(f"User {user_id} has no reviews with embeddings. Returning category-matched restaurants with default score.")
        return [schemas.RecommendedRestaurant(restaurant=rest, similarity_score=1.0) for rest in candidate_restaurants[:top_n]]

    user_combined_embedding = np.mean([np.array(r.review_embedding) for r in user_reviews], axis=0)

    restaurant_scores = []
    for rest in candidate_restaurants:
        score = 0.0
        if rest.text_embedding:
            text_sim = llm_service.cosine_similarity(user_combined_embedding, np.array(rest.text_embedding))
            score += text_sim * 0.7

        if rest.image_embedding:
            image_sim = llm_service.cosine_similarity(user_combined_embedding, np.array(rest.image_embedding))
            score += image_sim * 0.3
        
        if rest.category in preferred_categories:
            score += 0.05

        restaurant_scores.append((rest, score))

    restaurant_scores.sort(key=lambda x: x[1], reverse=True)
    
    for rest, score in restaurant_scores[:top_n]:
        recommended_restaurants.append(schemas.RecommendedRestaurant(restaurant=rest, similarity_score=score))
        
        db_rec = models.Recommendation(
            id=str(uuid.uuid4()),
            user_id=user_id,
            restaurant_id=rest.id,
            recommendation_score=int(score * 100),
            recommendation_type="hybrid_recommendation"
        )
        db.add(db_rec)
    db.commit()

    return recommended_restaurants

### ----------------------------------------------------
###               API 문서 저장 Endpoints (새로운 기능)
### ----------------------------------------------------
@app.get("/openapi.json", include_in_schema=False) # Swagger UI에서 직접 노출되지 않도록 설정
async def get_openapi_json():
    """
    FastAPI의 OpenAPI 명세서 JSON 파일을 반환합니다.
    이 엔드포인트는 FastAPI에 의해 자동으로 생성되지만, 명시적으로 정의하여 추가 작업을 할 수 있습니다.
    """
    return app.openapi() # FastAPI 앱의 OpenAPI 정의 반환

@app.get("/save-openapi-docs", summary="OpenAPI 명세서 JSON 파일로 저장")
async def save_openapi_docs(
    filename: str = "openapi_spec.json", # 저장할 파일 이름
    output_dir: str = "./docs_output" # 저장할 디렉토리
):
    """
    FastAPI의 OpenAPI 명세서(JSON 형식)를 파일로 저장합니다.
    지정된 디렉토리가 없으면 자동으로 생성합니다.
    """
    # OpenAPI JSON 명세서 가져오기
    openapi_data = app.openapi()

    # 출력 디렉토리 생성 (없으면)
    os.makedirs(output_dir, exist_ok=True)

    file_path = os.path.join(output_dir, filename)

    try:
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(openapi_data, f, indent=2, ensure_ascii=False) # JSON 파일 저장 (들여쓰기, 한글 인코딩)
        return JSONResponse(
            content={"message": f"OpenAPI documentation saved to {file_path}"},
            status_code=200
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to save OpenAPI documentation: {e}"
        )