from fastapi import FastAPI
from . import llm_service

app = FastAPI(title="NLP-PJT Test API")

@app.get("/")
def read_root():
    return {"message": "서버 정상 실행 중!"}

@app.post("/generate")
def generate(prompt: str):
    """
    임시 LLM 함수 호출
    """
    result = llm_service.generate_text(prompt)
    return {"result": result}
